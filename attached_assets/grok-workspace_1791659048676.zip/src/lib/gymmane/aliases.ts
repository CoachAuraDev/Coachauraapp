// Extracted from GymMane lib/catalog/exercise_aliases.dart (InlitX, GPL-3.0).
export const kExerciseAliases: Record<string, string[]> = {
  "Alternate Heel Touches": [
    "Alternate Heel Touchers"
  ],
  "Assisted Chest Dip (Kneeling)": [
    "Chest Dip (Assisted)",
    "Assisted Triceps Dip (Kneeling)"
  ],
  "Assisted Pull-up": [
    "Pull Up (Assisted)",
    "Assisted Pull Up (Machine)",
    "Assisted Parallel Close Grip Pull-up",
    "Assisted Standing Pull-up"
  ],
  "Back Extension": [
    "Weighted Hyperextension (On Stability Ball)"
  ],
  "Band Pull-Apart": [
    "Band Pullaparts"
  ],
  "Barbell Bench Press": [
    "Bench Press (Barbell)",
    "Flat Bench Press",
    "Cable Bench Press",
    "Barbell Guillotine Bench Press"
  ],
  "Barbell Bent Arm Pullover": [
    "Barbell Decline Bent Arm Pullover",
    "Barbell Pullover",
    "Barbell Pullover to Press"
  ],
  "Barbell Bent Over Row": [
    "Bent Over Row (Barbell)",
    "Barbell Row"
  ],
  "Barbell Close-grip Bench Press": [
    "Close Grip Bench Press (Barbell)",
    "Barbell Incline Close Grip Bench Press",
    "Smith Machine Decline Close Grip Bench Press"
  ],
  "Barbell Curl": [
    "Bicep Curl (Barbell)",
    "Barbell Bicep Curl",
    "Barbell Alternate Biceps Curl",
    "Barbell Biceps Curl (With Arm Blaster)"
  ],
  "Barbell Deadlift": [
    "Deadlift (Barbell)",
    "Conventional Deadlift",
    "Cable Deadlift",
    "Power Clean (Barbell)",
    "Power Clean"
  ],
  "Barbell Decline Bench Press": [
    "Decline Bench Press (Barbell)"
  ],
  "Barbell Decline Wide-grip Pullover": [
    "Barbell Decline Pullover"
  ],
  "Barbell Drag Curl": [
    "Cable Drag Curl"
  ],
  "Barbell Front Squat": [
    "Front Squat (Barbell)",
    "Barbell Clean-grip Front Squat",
    "Barbell Front Chest Squat"
  ],
  "Barbell Full Squat": [
    "Squat (Barbell)",
    "Back Squat",
    "Back Squat (Barbell)",
    "Barbell Squat",
    "High Bar Squat",
    "Barbell Squat (On Knees)",
    "Squat Jerk",
    "Barbell Full Squat (Back Pov)"
  ],
  "Barbell Glute Bridge": [
    "Glute Bridge (Barbell)",
    "Barbell Glute Bridge Two Legs on Bench"
  ],
  "Barbell Good Morning": [
    "Good Morning (Barbell)"
  ],
  "Barbell Hack Squat": [
    "Hack Squat (Barbell)"
  ],
  "Barbell Incline Bench Press": [
    "Incline Bench Press (Barbell)",
    "Cable Incline Bench Press",
    "Barbell Incline Reverse-grip Press"
  ],
  "Barbell Incline Triceps Extension": [
    "Smith Machine Incline Tricep Extension"
  ],
  "Barbell Lying Triceps Extension": [
    "Skullcrusher (Barbell)",
    "Lying Triceps Extension (Barbell)"
  ],
  "Barbell One Arm Snatch": [
    "Dumbbell One Arm Snatch"
  ],
  "Barbell Overhead Squat": [
    "Overhead Squat (Barbell)"
  ],
  "Barbell Pendlay Row": [
    "Pendlay Row (Barbell)"
  ],
  "Barbell Preacher Curl": [
    "Preacher Curl (Barbell)",
    "Barbell Lying Preacher Curl"
  ],
  "Barbell Push Press": [
    "Clean and Press (Barbell)",
    "Barbell Clean and Press"
  ],
  "Barbell Reverse Curl": [
    "Reverse Curl (Barbell)",
    "Barbell Reverse Preacher Curl"
  ],
  "Barbell Reverse Wrist Curl": [
    "Reverse Wrist Curl (Barbell)",
    "Barbell Palms Down Wrist Curl Over a Bench",
    "Barbell Revers Wrist Curl V. 2",
    "Barbell Standing Back Wrist Curl",
    "Smith Standing Back Wrist Curl",
    "Cable Standing Back Wrist Curl",
    "Dumbbell Lying Pronation",
    "Dumbbell Lying Pronation on Floor",
    "Cable Reverse Wrist Curl"
  ],
  "Barbell Rollerout": [
    "Ab Wheel",
    "Ab Wheel Rollout",
    "Barbell Rollerout from Bench",
    "Barbell Standing Ab Rollerout"
  ],
  "Barbell Romanian Deadlift": [
    "Romanian Deadlift (Barbell)",
    "Stiff Leg Deadlift (Barbell)",
    "Barbell Straight Leg Deadlift"
  ],
  "Barbell Seated Calf Raise": [
    "Seated Calf Raise (Barbell)",
    "Seated Calf Raise (Dumbbell)",
    "Dumbbell Seated Calf Raise",
    "Smith Seated One Leg Calf Raise"
  ],
  "Barbell Seated Overhead Press": [
    "Barbell Seated Behind Head Military Press"
  ],
  "Barbell Shrug": [
    "Shrug (Barbell)",
    "Barbell Incline Shoulder Raise",
    "Smith Incline Shoulder Raises",
    "Shrug (Machine)",
    "Lever Shrug",
    "Smith Back Shrug"
  ],
  "Barbell Single Leg Split Squat": [
    "Bulgarian Split Squat (Barbell)"
  ],
  "Barbell Standing Calf Raise": [
    "Standing Calf Raise (Barbell)",
    "Barbell Floor Calf Raise",
    "Cable Standing Calf Raise",
    "Barbell Standing Leg Calf Raise",
    "Standing Calf Raise (Dumbbell)",
    "Dumbbell Standing Calf Raise",
    "Smith Standing Leg Calf Raise"
  ],
  "Barbell Standing Wide Military Press": [
    "Overhead Press (Barbell)",
    "Shoulder Press (Barbell)",
    "Military Press (Barbell)",
    "Standing Military Press",
    "Barbell Seated Bradford Rocky Press"
  ],
  "Barbell Sumo Deadlift": [
    "Sumo Deadlift (Barbell)"
  ],
  "Barbell Wrist Curl": [
    "Wrist Curl (Barbell)",
    "Dumbbell Finger Curls",
    "Smith Seated Wrist Curl",
    "Barbell Palms Up Wrist Curl Over a Bench",
    "Wrist Rollerer",
    "Cable Wrist Curl",
    "Dumbbell Lying Supination",
    "Dumbbell Lying Supination on Floor"
  ],
  "Basic Toe Touch": [
    "Arms Apart Circular Toe Touch"
  ],
  "Belt Squat": [
    "Belt Squat (Machine)"
  ],
  "Bench Dip (Knees Bent)": [
    "Bench Dip",
    "Bench Dip on Floor"
  ],
  "Bench Pull-ups": [
    "Horizontal Row",
    "Bodyweight Squatting Row"
  ],
  "Bicycle Crunch": [
    "Bicycle Crunch (Bodyweight)"
  ],
  "Bodyweight Drop Jump Squat": [
    "Backward Jump",
    "Barbell Squat Jump Step Rear Lunge",
    "Dumbbell Plyo Squat"
  ],
  "Bodyweight Romanian Deadlift": [
    "Romanian Deadlift (Bodyweight)"
  ],
  "Bodyweight Single-Leg Deadlift": [
    "Single Leg Deadlift (Bodyweight)",
    "Single-Leg Romanian Deadlift (Bodyweight)"
  ],
  "Bodyweight Squat": [
    "Squat",
    "Squat (Bodyweight)",
    "Air Squat"
  ],
  "Bulgarian Split Squat": [
    "Bulgarian Split Squat (Bodyweight)"
  ],
  "Cable Crossover": [
    "Cable Fly Crossovers",
    "Chest Fly (Cable)",
    "Cable Cross-over Variation",
    "Cable Decline Fly"
  ],
  "Cable Curl": [
    "Bicep Curl (Cable)"
  ],
  "Cable Front Raise": [
    "Front Raise (Cable)",
    "Cable Forward Raise",
    "Cable Front Shoulder Raise"
  ],
  "Cable Hammer Curl (With Rope)": [
    "Hammer Curl (Cable)"
  ],
  "Cable Kneeling Crunch": [
    "Cable Crunch",
    "Kneeling Crunch (Cable)",
    "Cable Standing Crunch",
    "Cable Seated Crunch"
  ],
  "Cable Lateral Raise": [
    "Lateral Raise (Cable)"
  ],
  "Cable Overhead Triceps Extension (Rope Attachment)": [
    "Triceps Extension (Cable)",
    "Overhead Tricep Extension (Cable)",
    "Cable Alternate Triceps Extension",
    "Cable High Pulley Overhead Tricep Extension",
    "Bodyweight Kneeling Triceps Extension"
  ],
  "Cable Pulldown": [
    "Lat Pulldown (Cable)",
    "Lat Pulldown (Machine)",
    "Lat Pulldown",
    "Lat Pulldown Single Arm (Cable)",
    "Alternate Lateral Pulldown",
    "Cable Bar Lateral Pulldown",
    "Cable Cross-over Lateral Pulldown"
  ],
  "Cable Pushdown": [
    "Triceps Pushdown (Cable)",
    "Tricep Pushdown"
  ],
  "Cable Reverse Fly": [
    "Cable Cross-over Revers Fly",
    "Cable Kneeling Rear Delt Row (With Rope)",
    "Cable Rear Delt Row (Stirrups)"
  ],
  "Cable Seated Row": [
    "Seated Cable Row",
    "Seated Row (Cable)",
    "Seated Cable Row - Bar Grip",
    "Cable Decline Seated Wide-grip Row",
    "Cable Floor Seated Wide-grip Row",
    "Cable High Row (Kneeling)"
  ],
  "Cable Shrug": [
    "Shrug (Cable)"
  ],
  "Cable Woodchop": [
    "Cable Judo Flip",
    "Cable Seated Twist"
  ],
  "Chest Dip": [
    "Chest Dip (On Dip-pull-up Cage)",
    "Chest Dip on Straight Bar"
  ],
  "Chin-up": [
    "Chin Up",
    "Biceps Narrow Pull-ups",
    "Biceps Pull-up"
  ],
  "Close-Grip Lat Pulldown": [
    "Lat Pulldown - Close Grip (Cable)"
  ],
  "Close-grip Push-up": [
    "Diamond Push-up"
  ],
  "Crunch Floor": [
    "Crunch",
    "Crunch (Bodyweight)",
    "3/4 Sit-up",
    "Arms Overhead Full Sit-up"
  ],
  "Dead Bug": [
    "Deadbugs"
  ],
  "Dead Hang": [
    "Bar Hang",
    "Hang",
    "Back Lever"
  ],
  "Dumbbell Alternate Preacher Curl": [
    "Preacher Curl (Dumbbell)"
  ],
  "Dumbbell Arnold Press": [
    "Arnold Press (Dumbbell)",
    "Dumbbell Arnold Press V. 2",
    "Dumbbell Cuban Press"
  ],
  "Dumbbell Bench Press": [
    "Bench Press (Dumbbell)"
  ],
  "Dumbbell Bent Over Row": [
    "Bent Over Row (Dumbbell)",
    "Dumbbell Palm Rotational Bent Over Row"
  ],
  "Dumbbell Biceps Curl": [
    "Bicep Curl (Dumbbell)",
    "Dumbbell Bicep Curl",
    "Bicep Curl (Smith Machine)",
    "Smith Machine Bicep Curl",
    "Weighted Standing Curl",
    "Bodyweight Side Lying Biceps Curl",
    "Dumbbell Bicep Curl Lunge with Bowling Motion"
  ],
  "Dumbbell Concentration Curl": [
    "Concentration Curl (Dumbbell)",
    "Biceps Leg Concentration Curl",
    "Cable Concentration Curl"
  ],
  "Dumbbell Decline Bench Press": [
    "Decline Bench Press (Dumbbell)",
    "Dumbbell Decline Hammer Press",
    "Cable Decline Press",
    "Dumbbell Decline One Arm Hammer Press"
  ],
  "Dumbbell Decline Fly": [
    "Dumbbell Decline Twist Fly"
  ],
  "Dumbbell Fly": [
    "Chest Fly (Dumbbell)",
    "Dumbbell Flyes"
  ],
  "Dumbbell Front Raise": [
    "Front Raise (Dumbbell)",
    "Barbell Front Raise",
    "Dumbbell Front Raise V. 2"
  ],
  "Dumbbell Goblet Squat": [
    "Goblet Squat (Dumbbell)",
    "Dumbbell Supported Squat",
    "Weighted Squat"
  ],
  "Dumbbell Hammer Curl": [
    "Hammer Curl (Dumbbell)",
    "Dumbbell Alternate Seated Hammer Curl"
  ],
  "Dumbbell Hip Thrust": [
    "Hip Thrust (Dumbbell)"
  ],
  "Dumbbell Incline Bench Press": [
    "Incline Bench Press (Dumbbell)",
    "Dumbbell Incline Hammer Press on Exercise Ball"
  ],
  "Dumbbell Incline Row": [
    "Dumbbell Lying Rear Delt Row",
    "Barbell Incline Row",
    "Dumbbell Reverse Grip Incline Bench One Arm Row",
    "Dumbbell Reverse Grip Incline Bench Two Arm Row",
    "Cable Incline Bench Row"
  ],
  "Dumbbell Lateral Raise": [
    "Lateral Raise (Dumbbell)",
    "Side Lateral Raise",
    "Dumbbell Full Can Lateral Raise",
    "Dumbbell Incline One Arm Lateral Raise",
    "Dumbbell Incline Raise"
  ],
  "Dumbbell Lunge": [
    "Lunge (Dumbbell)",
    "Walking Lunge (Dumbbell)",
    "Weighted Lunge with Swing"
  ],
  "Dumbbell Lying Leg Curl": [
    "Dumbbell Lying Femoral"
  ],
  "Dumbbell Pullover": [
    "Pullover (Dumbbell)",
    "Dumbbell Around Pullover"
  ],
  "Dumbbell Rear Lateral Raise": [
    "Reverse Fly (Dumbbell)",
    "Rear Delt Fly (Dumbbell)",
    "Dumbbell Reverse Fly",
    "Barbell Rear Delt Raise"
  ],
  "Dumbbell Romanian Deadlift": [
    "Deadlift (Dumbbell)",
    "Dumbbell Deadlift"
  ],
  "Dumbbell Seated One Leg Calf Raise": [
    "Dumbbell Seated One Leg Calf Raise - Palm Up",
    "Dumbbell Seated One Leg Calf Raise - Hammer Grip"
  ],
  "Dumbbell Shrug": [
    "Shrug (Dumbbell)",
    "Dumbbell Incline Shoulder Raise",
    "Dumbbell Decline Shrug",
    "Dumbbell Incline Shrug"
  ],
  "Dumbbell Side Bend": [
    "45° Side Bend",
    "Barbell Side Bent V. 2",
    "Cable Side Bend"
  ],
  "Dumbbell Single Leg Calf Raise": [
    "Smith One Leg Floor Calf Raise"
  ],
  "Dumbbell Single Leg Split Squat": [
    "Bulgarian Split Squat (Dumbbell)",
    "Barbell Split Squat V. 2"
  ],
  "Dumbbell Standing Overhead Press": [
    "Shoulder Press (Dumbbell)",
    "Overhead Press (Dumbbell)",
    "Dumbbell Alternate Side Press"
  ],
  "Dumbbell Standing Triceps Extension": [
    "Triceps Extension (Dumbbell)",
    "Overhead Tricep Extension (Dumbbell)",
    "Dumbbell Forward Lunge Triceps Extension"
  ],
  "Dumbbell Step-up": [
    "Dumbbell Step-up Lunge",
    "Dumbbell Step-up Split Squat"
  ],
  "Dumbbell Triceps Kickback": [
    "Triceps Kickback (Cable)",
    "Cable Kickback"
  ],
  "Elliptical Trainer": [
    "Elliptical Machine",
    "Elliptical"
  ],
  "Face Pull": [
    "Face Pull (Cable)"
  ],
  "Hanging Knee Raise": [
    "Arm Slingers Hanging Bent Knee Legs"
  ],
  "Hanging Leg Raise": [
    "Weighted Hanging Leg-hip Raise",
    "Arm Slingers Hanging Straight Legs"
  ],
  "Hiking": [
    "Hike"
  ],
  "Hip Abduction Machine": [
    "Hip Abduction (Machine)"
  ],
  "Hip Adduction Machine": [
    "Hip Adduction (Machine)"
  ],
  "Hip Thrust": [
    "Hip Thrust (Bodyweight)"
  ],
  "Incline Dumbbell Curl": [
    "Incline Curl (Dumbbell)"
  ],
  "JM Press": [
    "Barbell Jm Bench Press"
  ],
  "Jump Rope": [
    "Skipping Rope"
  ],
  "Kettlebell Farmer Carry": [
    "Farmers Walk",
    "Farmers Carry",
    "Weighted Standing Hand Squeeze"
  ],
  "Kettlebell Goblet Squat": [
    "Goblet Squat (Kettlebell)"
  ],
  "Kettlebell Overhead Press": [
    "Overhead Press (Kettlebell)"
  ],
  "Kettlebell Romanian Deadlift": [
    "Romanian Deadlift (Kettlebell)"
  ],
  "Kettlebell Swing": [
    "Weighted Kneeling Step with Swing",
    "Dumbbell Clean"
  ],
  "Knee Push-up": [
    "Knee Push Up (Bodyweight)"
  ],
  "Landmine Press": [
    "Landmine Press (Barbell)"
  ],
  "Lateral Lunge": [
    "Barbell Side Split Squat"
  ],
  "Leg Extension": [
    "Knee Extension",
    "Resistance Band Leg Extension"
  ],
  "Leg Press": [
    "Smith Leg Press"
  ],
  "Leg Press Calf Raise": [
    "Lever Seated Squat Calf Raise on Leg Press Machine"
  ],
  "Lever Shoulder Press": [
    "Shoulder Press (Machine)",
    "Seated Shoulder Press (Machine)",
    "Cable Alternate Shoulder Press"
  ],
  "Lever Standing Calf Raise": [
    "Standing Calf Raise (Machine)",
    "Calf Raise (Machine)"
  ],
  "Lying Leg Curl": [
    "Standing Single Leg Curl"
  ],
  "Lying Leg Raise": [
    "Leg Raise (Bodyweight)"
  ],
  "Machine Chest Press": [
    "Chest Press (Machine)",
    "Seated Chest Press (Machine)",
    "Lever Standing Chest Press",
    "Machine Inner Chest Press"
  ],
  "Machine Glute Kickback": [
    "Glute Kickback (Machine)"
  ],
  "Machine Lateral Raise": [
    "Lateral Raise (Machine)"
  ],
  "Machine Reverse Fly": [
    "Rear Delt Reverse Fly (Machine)",
    "Reverse Fly (Machine)",
    "Lever Seated Reverse Fly"
  ],
  "Machine Seated Row": [
    "Seated Row (Machine)",
    "Iso-Lateral Row (Machine)",
    "Lever Seated Row"
  ],
  "Machine Triceps Extension": [
    "Triceps Extension (Machine)",
    "Lever Triceps Extension"
  ],
  "Meadows Row": [
    "Meadows Row (Barbell)"
  ],
  "Mountain Climber": [
    "Mountain Climbers"
  ],
  "Negative Pull-up": [
    "Pull-up Negatives"
  ],
  "Nordic Curl": [
    "Cable Assisted Inverse Leg Curl",
    "Self Assisted Inverse Leg Curl"
  ],
  "One-Arm Dumbbell Row": [
    "Single Arm Dumbbell Row",
    "Dumbbell Row"
  ],
  "Outdoor Cycling": [
    "Cycling",
    "Biking",
    "Bike Ride",
    "Road Cycling"
  ],
  "Outdoor Run": [
    "Running",
    "Run",
    "Jogging",
    "Jog"
  ],
  "Pec Deck": [
    "Chest Fly (Machine)",
    "Pec Deck (Machine)",
    "Butterfly (Machine)"
  ],
  "Plank": [
    "Front Plank",
    "Forearm Plank"
  ],
  "Plate Front Raise": [
    "Weighted Front Raise"
  ],
  "Pull-up": [
    "Pull Up",
    "Weighted Muscle Up"
  ],
  "Push-up": [
    "Push Up (Bodyweight)",
    "Press Up",
    "Deep Push Up",
    "Clock Push-up",
    "Body-up",
    "Modified Push Up to Lower Arms"
  ],
  "Quick Feet": [
    "Quick Feet V. 2"
  ],
  "Rack Pull": [
    "Snatch Pull"
  ],
  "Reverse Crunch": [
    "Cable Reverse Crunch"
  ],
  "Reverse Lunge": [
    "Reverse Lunge (Bodyweight)"
  ],
  "Rope Tricep Pushdown": [
    "Triceps Rope Pushdown (Cable)"
  ],
  "Rowing Machine": [
    "Rowing (Machine)",
    "Rowing"
  ],
  "Russian Twist": [
    "Russian Twist (Bodyweight)",
    "Cable Russian Twists (On Stability Ball)",
    "Barbell Seated Twist"
  ],
  "Scapular Pull-up": [
    "Scapular Pulls"
  ],
  "Seated Dumbbell Shoulder Press": [
    "Dumbbell Bench Seated Press"
  ],
  "Seated Knee Tuck": [
    "Barbell Sitted Alternate Leg Raise"
  ],
  "Seated Leg Curl": [
    "Leg Curl (Machine)",
    "Seated Leg Curl (Machine)"
  ],
  "Shrimp Squat": [
    "Advanced Shrimp Squat"
  ],
  "Side Plank": [
    "Side Bridge",
    "Bodyweight Incline Side Plank"
  ],
  "Single Dumbbell Skullcrusher": [
    "Skullcrusher (Dumbbell)",
    "Skull Crusher"
  ],
  "Single-Arm Cable Row": [
    "Seated Row Single Arm (Cable)"
  ],
  "Ski Erg": [
    "Ski Machine"
  ],
  "Smith Bench Press": [
    "Bench Press (Smith Machine)",
    "Smith Decline Bench Press",
    "Smith Decline Reverse-grip Press"
  ],
  "Smith Calf Raise": [
    "Smith Reverse Calf Raises"
  ],
  "Smith Full Squat": [
    "Smith Chair Squat",
    "Smith Front Squat (Clean Grip)"
  ],
  "Smith Good Morning": [
    "Smith Bent Knee Good Morning"
  ],
  "Smith Hack Squat": [
    "Hack Squat (Machine)"
  ],
  "Smith Hip Thrust": [
    "Smith Hip Raise"
  ],
  "Smith Machine Bulgarian Split Squat": [
    "Bulgarian Split Squat (Smith Machine)"
  ],
  "Smith Romanian Deadlift": [
    "Smith Deadlift"
  ],
  "Smith Shoulder Press": [
    "Smith Behind Neck Press",
    "Shoulder Press (Smith Machine)",
    "Smith Seated Shoulder Press",
    "Smith Standing Behind Head Military Press"
  ],
  "Split Squats": [
    "Suspended Split Squat"
  ],
  "Squat to Overhead Reach": [
    "Squat Sky Reaches",
    "Squat to Overhead Reach with Twist"
  ],
  "Stair Climber": [
    "Stair Machine",
    "Stairmaster"
  ],
  "Stationary Bike": [
    "Cycling (Indoor)",
    "Indoor Cycling"
  ],
  "Step-down": [
    "Box Jump Down with One Leg Stabilization"
  ],
  "Swimming": [
    "Swim",
    "Pool Swim"
  ],
  "T-Bar Row": [
    "T Bar Row",
    "T Bar Row (Machine)",
    "Lever T Bar Row"
  ],
  "Towel Hamstring Stretch": [
    "Single Leg Platform Slide"
  ],
  "Trap Bar Deadlift": [
    "Deadlift (Trap Bar)",
    "Hex Bar Deadlift"
  ],
  "Treadmill Run": [
    "Running (Treadmill)",
    "Treadmill"
  ],
  "Treadmill Walk": [
    "Walking (Treadmill)"
  ],
  "Triceps Dip": [
    "Triceps Dip (Bodyweight)",
    "Tricep Dip"
  ],
  "Upright Row": [
    "Upright Row (Barbell)",
    "Upright Row (Cable)"
  ],
  "Vertical Row": [
    "Bodyweight Standing Close-grip Row",
    "Bodyweight Standing Close-grip One Arm Row",
    "Bodyweight Standing One Arm Row"
  ],
  "Walk": [
    "Walking",
    "Outdoor Walk"
  ],
  "Weighted Arm Circles": [
    "Weighted Round Arm"
  ],
  "Weighted Bench Dip": [
    "Weighted Three Bench Dips"
  ],
  "Weighted Chin-up": [
    "Weighted Close Grip Chin-up on Dip Cage"
  ],
  "Weighted Crunch": [
    "Weighted Overhead Crunch (On Stability Ball)"
  ],
  "Weighted Decline Sit-up": [
    "Barbell Press Sit-up"
  ],
  "Weighted Front Plank": [
    "Weighted Plank",
    "Plank (Weighted)"
  ],
  "Weighted Pull-up": [
    "Pull Up (Weighted)",
    "Weighted One Hand Pull Up"
  ],
  "Weighted Push-up": [
    "Weighted Drop Push Up"
  ],
  "Weighted Russian Twist": [
    "Russian Twist (Weighted)",
    "Weighted Seated Twist (On Stability Ball)",
    "Bent Knee Lying Twist"
  ],
  "Weighted Tricep Dips": [
    "Weighted Straight Bar Dip",
    "Weighted Triceps Dip on High Parallel Bars"
  ],
  "Wide-Grip Lat Pulldown": [
    "Lat Pulldown - Wide Grip (Cable)"
  ],
  "Zercher Squat": [
    "Barbell Full Zercher Squat"
  ]
};
